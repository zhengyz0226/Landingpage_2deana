var config = {
    apiKey: "AIzaSyBoQfbYWBo5E2y79Wp6h-IKcEazLmmmQ78",
    authDomain: "push-buying.firebaseapp.com",
    databaseURL: "https://push-buying.firebaseapp.com",
    projectId: "push-buying",
    storageBucket: "push-buying.appspot.com",
    messagingSenderId: "740531458101",
    appId: "1:740531458101:web:fad23a5bfdf3a7ae19617c",
    measurementId: "G-4WSW3BG9YK"
};
firebase.initializeApp(config);